"""Build the two required Phase 3 notebooks from verified artifacts."""

from __future__ import annotations

from pathlib import Path

import nbformat as nbf

from src.phase3_data import PROJECT_ROOT

NOTEBOOK_DIR = PROJECT_ROOT / "notebooks"


def _code(source: str):
    return nbf.v4.new_code_cell(source.strip())


def _markdown(source: str):
    return nbf.v4.new_markdown_cell(source.strip())


SETUP = """
from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, Markdown

ROOT = Path.cwd()
if not (ROOT / "phase3_spec.json").exists():
    ROOT = ROOT.parent
RESULTS = ROOT / "results" / "phase3"
spec = json.loads((ROOT / "phase3_spec.json").read_text(encoding="utf-8"))
aggregate = pd.read_csv(RESULTS / "aggregate_metrics.csv")
per_seed = pd.read_csv(RESULTS / "per_seed_metrics.csv")
split_audit = json.loads((RESULTS / "split_overlap_audit.json").read_text())
gate_a = json.loads((RESULTS / "gate_a_report.json").read_text())
gate_b = json.loads((RESULTS / "gate_b_report.json").read_text())
gate_c = json.loads((RESULTS / "gate_c_report.json").read_text())
numerical = json.loads((RESULTS / "numerical_audit.json").read_text())
print("Loaded verified Phase 3 artifacts:", RESULTS)
"""

SPLITS = """
split_rows = []
for name, row in split_audit["split_reports"].items():
    split_rows.append({
        "split": name,
        "samples": row["sample_count"],
        "class_0": row["class_counts"]["0"],
        "class_1": row["class_counts"]["1"],
        "unique_structures": row["unique_invariant_structures"],
        "status": row["status"],
        "sha256": row["file_sha256"],
    })
display(pd.DataFrame(split_rows))
assert split_audit["status"] == "PASS"
"""

GATES = """
display(pd.DataFrame([{
    "gate": "A",
    "status": gate_a["status"],
    "samples_or_seeds": gate_a["oracle_sample_count"],
    "key_result": gate_a["oracle_accuracy"],
}, {
    "gate": "B",
    "status": gate_b["status"],
    "samples_or_seeds": gate_b["completed_seed_count"],
    "key_result": min(row["accuracy"] for row in gate_b["per_seed"]),
}, {
    "gate": "C",
    "status": gate_c["status"],
    "samples_or_seeds": gate_c["completed_seed_count"],
    "key_result": min(row["train_metrics"]["accuracy"] for row in gate_c["per_seed"]),
}]))
assert gate_a["status"] == gate_b["status"] == gate_c["status"] == "PASS"
"""

METRICS = """
test_splits = ["iid_test", "ood_template_test", "ood_size_test"]
columns = [
    "model", "role", "split", "accuracy_mean", "accuracy_std",
    "balanced_accuracy_mean", "macro_f1_mean", "macro_f1_std",
    "roc_auc_mean", "seed_count",
]
test_metrics = aggregate[aggregate["split"].isin(test_splits)][columns]
display(test_metrics)
assert (test_metrics["seed_count"] == 5).all()
"""

PLOT = """
plot_data = test_metrics.pivot(index="model", columns="split", values="macro_f1_mean")
ax = plot_data.plot(kind="bar", figsize=(12, 5), ylim=(0, 1.05))
ax.set_title("Macro F1 by model and locked evaluation split")
ax.set_ylabel("Mean macro F1 across five seeds")
ax.set_xlabel("")
ax.legend(title="Split")
plt.xticks(rotation=35, ha="right")
plt.tight_layout()
plt.show()
"""

NUMERICAL = """
numerical_table = pd.DataFrame([
    {
        "quantity": name,
        "maximum": values["maximum"],
        "p99": values["p99"],
        "tolerance": values["tolerance"],
        "failures": values["failed_count"],
    }
    for name, values in numerical["quantities"].items()
])
display(numerical_table)
print("Audited seed-sample evaluations:", numerical["audited_sample_count"])
assert numerical["status"] == "PASS"
assert (numerical_table["failures"] == 0).all()
"""

REPRODUCTION = """
commands = [
    "python -m src.generate_phase3_datasets",
    "python -m src.audit_splits",
    "python -m src.phase3_experiments",
    "python -m src.audit_model_numerics",
    "python -m src.reporting",
    "python -m pytest -q",
]
print("\\n".join(commands))
"""


def research_notebook():
    notebook = nbf.v4.new_notebook()
    notebook["metadata"]["kernelspec"] = {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3",
    }
    notebook["cells"] = [
        _markdown(
            """# Phase 3 Research — Hypergraph Equivalence

This notebook is the clean-executed, artifact-backed companion to the final
validation report. It distinguishes the designated primary model from the
numerically best model and never uses test performance for checkpoint selection."""
        ),
        _code(SETUP),
        _markdown(
            """## The locked corpus removes the inherited structural leakage

Class 2 examples preserve row-size and column-degree margins but change the
multiset of incident neighbor sets through a degree-preserving switch. Class 3
examples preserve that multiset exactly. Validation selects checkpoints; IID,
OOD-template, and OOD-size remain evaluation-only."""
        ),
        _code(SPLITS),
        _markdown(
            """## MatchingNetwork is the designated primary model

The primary model uses fixed normalized L1 row cost and a balanced Sinkhorn
coupling. Baselines are MLP_Baseline, NestedDeepSets, and BipartiteEncoder.
Ablations are LearnedCostSinkhorn, StraightThroughHungarian, and NoSinkhorn.
Primary identity is specification-driven, not chosen after viewing metrics."""
        ),
        _markdown(
            """## Normalized Sinkhorn mass

The coupling has total mass 1. With `m` valid, equally weighted rows and
columns, each marginal is `1/m`; a hard matched entry is therefore about
`1/m`, not 1. Gate A verifies this with 500 float64 iterations."""
        ),
        _code(GATES),
        _markdown(
            """## Five-seed IID and OOD evidence

The table reports means and sample standard deviations from seeds 42, 100,
2026, 777, and 999. Exact per-seed probabilities remain in prediction CSVs."""
        ),
        _code(METRICS),
        _code(PLOT),
        _markdown(
            """## Complete structural audit

Every primary checkpoint is checked on every IID, OOD-template, and OOD-size
sample using compact float64 submatrices. Checks cover finiteness,
non-negativity, mass/marginals, root-swap transpose behavior, final score, row
permutations, and joint column permutations."""
        ),
        _code(NUMERICAL),
        _markdown(
            """## Limitations

The evidence is synthetic and local to the incidence-star classification task.
Five seeds measure optimization variability on fixed data, not population
uncertainty. OOD results apply to the locked switch/size generator families and
do not prove universal generalization to empirical hypergraphs."""
        ),
        _markdown("## Exact reproduction commands"),
        _code(REPRODUCTION),
    ]
    return notebook


def persian_notebook():
    notebook = nbf.v4.new_notebook()
    notebook["metadata"]["kernelspec"] = {
        "display_name": "Python 3",
        "language": "python",
        "name": "python3",
    }
    notebook["cells"] = [
        _markdown(
            """# توضیح مرحلهٔ سوم پژوهش هم‌ارزی ابرگراف

این دفترچه از خروجی‌های نهایی و راستی‌آزمایی‌شده خوانده می‌شود. مدل اصلی
`MatchingNetwork` طبق مشخصات پروژه تعیین شده است، نه بر اساس بهترین نتیجهٔ
آزمون."""
        ),
        _code(SETUP),
        _markdown(
            """## داده‌ها و جداسازی مجموعه‌ها

در کلاس ۲، حاشیه‌های سطر و ستون حفظ می‌شوند اما چندمجموعهٔ همسایه‌های
یال‌های واقع بر رأس یکسان نیست. در کلاس ۳ این چندمجموعه دقیقاً برابر است.
داده‌های آموزش، اعتبارسنجی، آزمون IID، آزمون OOD-الگو و OOD-اندازه هیچ
هم‌پوشانی ممنوعی ندارند. انتخاب checkpoint فقط با اعتبارسنجی انجام شده است."""
        ),
        _code(SPLITS),
        _markdown(
            """## معنای جرم در Sinkhorn

جرم کل ماتریس کوپلینگ برابر ۱ است. اگر `m` سطر معتبر و هم‌وزن داشته باشیم،
حاشیهٔ هر سطر و ستون `1/m` است؛ بنابراین مقدار یک تطبیق سخت تقریباً `1/m`
است، نه ۱. آزمون Gate A این تفسیر را با محاسبات float64 بررسی می‌کند."""
        ),
        _code(GATES),
        _markdown(
            """## نتایج پنج seed

اعداد زیر میانگین و انحراف معیار نمونه‌ای روی seedهای 42، 100، 2026، 777 و
999 هستند. نتایج IID، OOD-الگو و OOD-اندازه جدا گزارش شده‌اند."""
        ),
        _code(METRICS),
        _code(PLOT),
        _markdown(
            """## ممیزی عددی کامل

برای تمام نمونه‌های سه مجموعهٔ آزمون و هر پنج checkpoint مدل اصلی، تقارن
تعویض ریشه، ترانهاده‌شدن هزینه و کوپلینگ، جرم و حاشیه‌ها، نبود NaN/Inf،
نامنفی‌بودن، جایگشت سطرهای یال و جایگشت مشترک ستون‌های همسایه بررسی شده است."""
        ),
        _code(NUMERICAL),
        _markdown(
            """## محدودیت‌ها

داده‌ها مصنوعی‌اند و نتیجه دربارهٔ همین تعریف محلی و خانواده‌های مولد قفل‌شده
است. پنج seed عدم‌قطعیت بهینه‌سازی را نشان می‌دهد، نه عدم‌قطعیت یک جامعهٔ
واقعی. برای تعمیم بیرونی باید مولدهای مستقل و ابرگراف‌های تجربی نیز آزموده
شوند."""
        ),
        _markdown("## فرمان‌های بازتولید"),
        _code(REPRODUCTION),
    ]
    return notebook


def main() -> None:
    NOTEBOOK_DIR.mkdir(parents=True, exist_ok=True)
    nbf.write(research_notebook(), NOTEBOOK_DIR / "Phase3_Research.ipynb")
    nbf.write(persian_notebook(), NOTEBOOK_DIR / "Phase3_Explained_FA.ipynb")


if __name__ == "__main__":
    main()
