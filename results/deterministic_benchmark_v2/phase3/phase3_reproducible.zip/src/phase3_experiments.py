"""Locked Phase 3 gates, training, prediction, and metric aggregation."""

from __future__ import annotations

import copy
import hashlib
import json
import random
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    f1_score,
    precision_recall_fscore_support,
    roc_auc_score,
)

from src.config_manager import generate_configs, load_config, model_names
from src.differentiable_matching import (
    DifferentiableIncidenceMatchingNetwork,
    initialize_model,
)
from src.phase3_data import (
    PROJECT_ROOT,
    collate_samples,
    exact_hungarian_cost,
    exact_label,
    file_sha256,
    load_spec,
    load_splits,
)

RESULT_DIR = PROJECT_ROOT / "results" / "phase3"
CHECKPOINT_DIR = RESULT_DIR / "checkpoints"
PREDICTION_DIR = RESULT_DIR / "predictions"
DEVICE = torch.device("cpu")
DTYPE = torch.float32


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)


def _tensor_batch(
    samples: list[dict[str, Any]], dtype: torch.dtype = DTYPE
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    bx, by, labels = collate_samples(samples, dtype=dtype)
    return bx.to(DEVICE), by.to(DEVICE), labels.to(DEVICE)


def _metrics(labels: np.ndarray, probabilities: np.ndarray) -> dict[str, Any]:
    predictions = (probabilities >= 0.5).astype(int)
    loss = float(
        F.binary_cross_entropy(
            torch.tensor(probabilities, dtype=torch.float64).clamp(1e-12, 1 - 1e-12),
            torch.tensor(labels, dtype=torch.float64),
        ).item()
    )
    precision, recall, per_class_f1, support = precision_recall_fscore_support(
        labels, predictions, labels=[0, 1], zero_division=0
    )
    return {
        "loss": loss,
        "accuracy": float(accuracy_score(labels, predictions)),
        "balanced_accuracy": float(balanced_accuracy_score(labels, predictions)),
        "macro_f1": float(f1_score(labels, predictions, average="macro")),
        "roc_auc": float(roc_auc_score(labels, probabilities)),
        "pr_auc": float(average_precision_score(labels, probabilities)),
        "brier_score": float(brier_score_loss(labels, probabilities)),
        "sample_count": int(len(labels)),
        "class_0_count": int((labels == 0).sum()),
        "class_1_count": int((labels == 1).sum()),
        "class_0_precision": float(precision[0]),
        "class_1_precision": float(precision[1]),
        "class_0_recall": float(recall[0]),
        "class_1_recall": float(recall[1]),
        "class_0_f1": float(per_class_f1[0]),
        "class_1_f1": float(per_class_f1[1]),
        "class_0_support": int(support[0]),
        "class_1_support": int(support[1]),
    }


def predict(
    model: torch.nn.Module,
    samples: list[dict[str, Any]],
    batch_size: int = 200,
) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    all_labels: list[np.ndarray] = []
    all_probabilities: list[np.ndarray] = []
    with torch.no_grad():
        for start in range(0, len(samples), batch_size):
            bx, by, labels = _tensor_batch(samples[start : start + batch_size])
            probabilities = torch.sigmoid(model(bx, by))
            all_labels.append(labels.cpu().numpy())
            all_probabilities.append(probabilities.cpu().numpy())
    return np.concatenate(all_labels), np.concatenate(all_probabilities)


def _validation_score(
    model: torch.nn.Module, samples: list[dict[str, Any]]
) -> tuple[float, float]:
    labels, probabilities = predict(model, samples)
    metrics = _metrics(labels, probabilities)
    return metrics["macro_f1"], metrics["loss"]


def train_model(
    model_name: str,
    seed: int,
    train_samples: list[dict[str, Any]],
    validation_samples: list[dict[str, Any]],
    *,
    max_epochs: int | None = None,
    patience: int | None = None,
) -> tuple[torch.nn.Module, dict[str, Any]]:
    spec = load_spec()
    settings = spec["training"]
    max_epochs = int(max_epochs or settings["max_epochs"])
    patience = int(patience or settings["patience"])
    set_seed(seed)
    config = load_config(model_name)
    model = initialize_model(config).to(device=DEVICE, dtype=DTYPE)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(settings["learning_rate"]),
        weight_decay=float(settings["weight_decay"]),
    )
    bx, by, labels = _tensor_batch(train_samples)
    best_macro_f1, best_loss = _validation_score(model, validation_samples)
    best_state = copy.deepcopy(model.state_dict())
    best_epoch = 0
    best_tau = float(getattr(model, "temp", config["tau_start"]))
    epochs_without_improvement = 0
    patience_macro_f1 = best_macro_f1
    patience_loss = best_loss
    history: list[dict[str, float | int]] = []
    start_time = time.perf_counter()

    for epoch in range(1, max_epochs + 1):
        if isinstance(model, DifferentiableIncidenceMatchingNetwork):
            fraction = epoch / max_epochs
            tau = config["tau_start"] * (
                config["tau_final"] / config["tau_start"]
            ) ** fraction
            model.temp = float(tau)
        model.train()
        optimizer.zero_grad(set_to_none=True)
        logits = model(bx, by)
        loss = F.binary_cross_entropy_with_logits(logits, labels)
        loss.backward()
        gradient_norm = float(
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), float(settings["gradient_clip"])
            ).item()
        )
        optimizer.step()
        validation_macro_f1, validation_loss = _validation_score(
            model, validation_samples
        )
        history.append(
            {
                "epoch": epoch,
                "train_loss": float(loss.item()),
                "validation_macro_f1": validation_macro_f1,
                "validation_loss": validation_loss,
                "gradient_norm": gradient_norm,
                "temperature": float(getattr(model, "temp", 0.0)),
            }
        )
        improved = validation_macro_f1 > best_macro_f1 + 1e-12 or (
            abs(validation_macro_f1 - best_macro_f1) <= 1e-12
            and validation_loss < best_loss - 1e-12
        )
        if improved:
            best_macro_f1 = validation_macro_f1
            best_loss = validation_loss
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            best_tau = float(getattr(model, "temp", config["tau_start"]))
        significant_improvement = (
            validation_macro_f1 > patience_macro_f1 + 1e-12
            or (
                abs(validation_macro_f1 - patience_macro_f1) <= 1e-12
                and validation_loss < patience_loss - 1e-4
            )
        )
        if significant_improvement:
            patience_macro_f1 = validation_macro_f1
            patience_loss = validation_loss
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        if epochs_without_improvement >= patience:
            break

    model.load_state_dict(best_state)
    model.eval()
    metadata = {
        "model": model_name,
        "seed": seed,
        "selection_epoch": best_epoch,
        "selection_criterion": spec["gate_c"]["checkpoint_selection"],
        "validation_macro_f1": best_macro_f1,
        "validation_loss": best_loss,
        "selected_temperature": best_tau,
        "epochs_executed": len(history),
        "runtime_seconds": time.perf_counter() - start_time,
        "device": str(DEVICE),
        "dtype": str(DTYPE),
        "train_sinkhorn_iterations": int(config["train_iters"]),
        "evaluation_sinkhorn_iterations": int(config["eval_iters"]),
        "history": history,
    }
    return model, metadata


def run_gate_a() -> dict[str, Any]:
    spec = load_spec()
    splits = load_splits()
    rows: list[dict[str, Any]] = []
    oracle_failures: list[str] = []
    for split, samples in splits.items():
        for sample in samples:
            bx = np.asarray(sample["B_x"], dtype=np.float64)
            by = np.asarray(sample["B_y"], dtype=np.float64)
            prediction = exact_label(bx, by)
            cost = exact_hungarian_cost(bx, by)
            if prediction != int(sample["label"]):
                oracle_failures.append(sample["sample_id"])
            rows.append(
                {
                    "sample_id": sample["sample_id"],
                    "split": split,
                    "label": sample["label"],
                    "oracle_prediction": prediction,
                    "hard_assignment_cost": cost,
                    "m": sample["m"],
                    "k": sample["k"],
                }
            )
    predictions_path = RESULT_DIR / "gate_a_predictions.csv"
    pd.DataFrame(rows).to_csv(predictions_path, index=False)

    reference_samples = [
        splits["train"][0],
        splits["train"][1],
        splits["ood_size_test"][0],
        splits["ood_size_test"][1],
    ]
    model = initialize_model(load_config("MatchingNetwork")).double().eval()
    bx, by, _ = _tensor_batch(reference_samples, torch.float64)
    with torch.no_grad():
        _, auxiliary, _ = model(bx, by, return_aux=True)
        coupling = model.sinkhorn(
            auxiliary["C"],
            auxiliary["mask_x"],
            auxiliary["mask_y"],
            num_iters=int(spec["gate_a"]["sinkhorn_iterations"]),
        )
    expected_rows = auxiliary["mask_x"] / auxiliary["mask_x"].sum(
        dim=1, keepdim=True
    )
    expected_columns = auxiliary["mask_y"] / auxiliary["mask_y"].sum(
        dim=1, keepdim=True
    )
    mass_error = float((coupling.sum((1, 2)) - 1).abs().max().item())
    row_residual = float(
        (coupling.sum(2) - expected_rows).abs().max().item()
    )
    column_residual = float(
        (coupling.sum(1) - expected_columns).abs().max().item()
    )
    observed_cost = (
        coupling * auxiliary["C_base"]
    ).sum((1, 2)).detach().cpu().numpy()
    tolerance = float(spec["gate_a"]["structural_tolerance"])
    status = (
        "PASS"
        if not oracle_failures
        and mass_error <= tolerance
        and row_residual <= tolerance
        and column_residual <= tolerance
        else "FAIL"
    )
    report = {
        "schema_version": "phase3-gate-a-v2",
        "status": status,
        "oracle_sample_count": len(rows),
        "oracle_accuracy": 1.0 - len(oracle_failures) / len(rows),
        "oracle_failed_sample_ids": oracle_failures,
        "coupling_normalization": "total mass 1; every valid row and column has marginal 1/m",
        "expected_total_mass": 1.0,
        "expected_hard_matched_entry": "1/m, not 1.0",
        "sinkhorn_iterations": int(spec["gate_a"]["sinkhorn_iterations"]),
        "maximum_total_mass_error": mass_error,
        "maximum_row_marginal_residual": row_residual,
        "maximum_column_marginal_residual": column_residual,
        "tolerance": tolerance,
        "reference_inputs": [
            {
                "sample_id": sample["sample_id"],
                "B_x": sample["B_x"],
                "B_y": sample["B_y"],
                "label": sample["label"],
                "m": sample["m"],
                "expected_row_column_marginal": 1.0 / sample["m"],
                "observed_matching_cost": float(observed_cost[index]),
            }
            for index, sample in enumerate(reference_samples)
        ],
        "predictions_path": str(predictions_path.relative_to(PROJECT_ROOT)),
    }
    (RESULT_DIR / "gate_a_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    return report


def run_gate_b() -> dict[str, Any]:
    spec = load_spec()
    train_samples = load_splits(["train"])["train"]
    selected = [
        sample for sample in train_samples if sample["label"] == 0
    ][:32] + [
        sample for sample in train_samples if sample["label"] == 1
    ][:32]
    per_seed: list[dict[str, Any]] = []
    for seed in spec["seeds"]:
        model, training = train_model(
            "MatchingNetwork",
            seed,
            selected,
            selected,
            max_epochs=int(spec["gate_b"]["epochs"]),
            patience=20,
        )
        labels, probabilities = predict(model, selected, batch_size=64)
        metrics = _metrics(labels, probabilities)
        predictions = (probabilities >= 0.5).astype(int)
        failed_ids = [
            sample["sample_id"]
            for sample, label, prediction in zip(selected, labels, predictions)
            if int(label) != int(prediction)
        ]
        passed = (
            metrics["accuracy"] >= spec["gate_b"]["accuracy_threshold"]
            and metrics["macro_f1"] >= spec["gate_b"]["macro_f1_threshold"]
            and min(metrics["class_0_f1"], metrics["class_1_f1"])
            >= spec["gate_b"]["per_class_f1_threshold"]
        )
        history = training["history"]
        per_seed.append(
            {
                "seed": seed,
                "sample_count": len(selected),
                **metrics,
                "failed_sample_ids": failed_ids,
                "accuracy_threshold": spec["gate_b"]["accuracy_threshold"],
                "macro_f1_threshold": spec["gate_b"]["macro_f1_threshold"],
                "per_class_f1_threshold": spec["gate_b"]["per_class_f1_threshold"],
                "selection_epoch": training["selection_epoch"],
                "epochs_executed": training["epochs_executed"],
                "final_temperature": training["selected_temperature"],
                "gradient_norm_first": history[0]["gradient_norm"],
                "gradient_norm_last": history[-1]["gradient_norm"],
                "loss_first": history[0]["train_loss"],
                "loss_last": history[-1]["train_loss"],
                "sinkhorn_iterations": load_config("MatchingNetwork")["eval_iters"],
                "status": "PASS" if passed else "FAIL",
            }
        )
    report = {
        "schema_version": "phase3-gate-b-v2",
        "model": "MatchingNetwork",
        "status": "PASS"
        if all(row["status"] == "PASS" for row in per_seed)
        else "FAIL",
        "completed_seed_count": len(per_seed),
        "required_seed_count": len(spec["seeds"]),
        "per_seed": per_seed,
    }
    (RESULT_DIR / "gate_b_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    return report


def _checkpoint_payload(
    model: torch.nn.Module, metadata: dict[str, Any]
) -> dict[str, Any]:
    return {
        "schema_version": "phase3-checkpoint-v2",
        "model_name": metadata["model"],
        "seed": metadata["seed"],
        "model_config": load_config(metadata["model"]),
        "state_dict": model.state_dict(),
        "metadata": metadata,
    }


def run_experiments() -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    spec = load_spec()
    splits = load_splits()
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    PREDICTION_DIR.mkdir(parents=True, exist_ok=True)
    generate_configs()
    metric_rows: list[dict[str, Any]] = []
    gate_c_rows: list[dict[str, Any]] = []
    for model_name in model_names():
        for seed in spec["seeds"]:
            model, metadata = train_model(
                model_name, seed, splits["train"], splits["validation"]
            )
            checkpoint_path = CHECKPOINT_DIR / f"{model_name}_seed{seed}.pt"
            torch.save(_checkpoint_payload(model, metadata), checkpoint_path)
            metadata["checkpoint_sha256"] = file_sha256(checkpoint_path)
            for split_name, samples in splits.items():
                labels, probabilities = predict(model, samples)
                predictions = (probabilities >= 0.5).astype(int)
                prediction_path = (
                    PREDICTION_DIR
                    / f"{model_name}_seed{seed}_{split_name}.csv"
                )
                pd.DataFrame(
                    {
                        "sample_id": [sample["sample_id"] for sample in samples],
                        "matched_pair_id": [
                            sample["matched_pair_id"] for sample in samples
                        ],
                        "label": labels.astype(int),
                        "probability": probabilities,
                        "prediction": predictions,
                        "correct": predictions == labels,
                        "m": [sample["m"] for sample in samples],
                        "k": [sample["k"] for sample in samples],
                    }
                ).to_csv(prediction_path, index=False)
                metrics = _metrics(labels, probabilities)
                metric_rows.append(
                    {
                        "model": model_name,
                        "role": spec["model_roles"][model_name],
                        "seed": seed,
                        "split": split_name,
                        **metrics,
                        "selection_epoch": metadata["selection_epoch"],
                        "selected_temperature": metadata["selected_temperature"],
                        "checkpoint_sha256": metadata["checkpoint_sha256"],
                        "prediction_sha256": file_sha256(prediction_path),
                    }
                )
            if model_name == spec["primary_model"]:
                train_row = metric_rows[-len(splits)]
                passed = (
                    train_row["accuracy"]
                    >= spec["gate_c"]["train_accuracy_threshold"]
                    and train_row["balanced_accuracy"]
                    >= spec["gate_c"]["train_balanced_accuracy_threshold"]
                    and train_row["macro_f1"]
                    >= spec["gate_c"]["train_macro_f1_threshold"]
                    and min(
                        train_row["class_0_recall"],
                        train_row["class_1_recall"],
                    )
                    >= spec["gate_c"]["train_min_class_recall_threshold"]
                )
                gate_c_rows.append(
                    {
                        "seed": seed,
                        "status": "PASS" if passed else "FAIL",
                        "train_metrics": {
                            key: train_row[key]
                            for key in (
                                "loss",
                                "accuracy",
                                "balanced_accuracy",
                                "macro_f1",
                                "class_0_recall",
                                "class_1_recall",
                            )
                        },
                        "selection_epoch": metadata["selection_epoch"],
                        "selection_criterion": metadata["selection_criterion"],
                        "selected_temperature": metadata["selected_temperature"],
                        "train_sinkhorn_iterations": metadata[
                            "train_sinkhorn_iterations"
                        ],
                        "evaluation_sinkhorn_iterations": metadata[
                            "evaluation_sinkhorn_iterations"
                        ],
                        "checkpoint": str(checkpoint_path.relative_to(PROJECT_ROOT)),
                        "checkpoint_sha256": metadata["checkpoint_sha256"],
                    }
                )
    per_seed = pd.DataFrame(metric_rows)
    per_seed_path = RESULT_DIR / "per_seed_metrics.csv"
    per_seed.to_csv(per_seed_path, index=False)
    numeric_metrics = [
        "loss",
        "accuracy",
        "balanced_accuracy",
        "macro_f1",
        "roc_auc",
        "pr_auc",
        "brier_score",
        "sample_count",
        "class_0_count",
        "class_1_count",
        "class_0_precision",
        "class_1_precision",
        "class_0_recall",
        "class_1_recall",
        "class_0_f1",
        "class_1_f1",
    ]
    aggregate = (
        per_seed.groupby(["model", "role", "split"], sort=False)[numeric_metrics]
        .agg(["mean", "std"])
        .reset_index()
    )
    aggregate.columns = [
        "_".join(column).rstrip("_") if isinstance(column, tuple) else column
        for column in aggregate.columns
    ]
    counts = (
        per_seed.groupby(["model", "role", "split"], sort=False)["seed"]
        .nunique()
        .rename("seed_count")
        .reset_index()
    )
    aggregate = aggregate.merge(counts, on=["model", "role", "split"])
    aggregate_path = RESULT_DIR / "aggregate_metrics.csv"
    aggregate.to_csv(aggregate_path, index=False)
    gate_c = {
        "schema_version": "phase3-gate-c-v2",
        "model": spec["primary_model"],
        "status": "PASS"
        if len(gate_c_rows) == len(spec["seeds"])
        and all(row["status"] == "PASS" for row in gate_c_rows)
        else "FAIL",
        "completed_seed_count": len(gate_c_rows),
        "required_seed_count": len(spec["seeds"]),
        "thresholds": spec["gate_c"],
        "per_seed": gate_c_rows,
    }
    (RESULT_DIR / "gate_c_report.json").write_text(
        json.dumps(gate_c, indent=2) + "\n", encoding="utf-8"
    )
    return per_seed, aggregate, gate_c


def rerun_affected_model(model_name: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Rerun only one repaired model while preserving every unaffected run."""

    spec = load_spec()
    if model_name not in model_names():
        raise KeyError(model_name)
    splits = load_splits()
    existing = pd.read_csv(RESULT_DIR / "per_seed_metrics.csv")
    retained = existing[existing["model"] != model_name].copy()
    replacement_rows: list[dict[str, Any]] = []
    for seed in spec["seeds"]:
        model, metadata = train_model(
            model_name, seed, splits["train"], splits["validation"]
        )
        checkpoint_path = CHECKPOINT_DIR / f"{model_name}_seed{seed}.pt"
        torch.save(_checkpoint_payload(model, metadata), checkpoint_path)
        metadata["checkpoint_sha256"] = file_sha256(checkpoint_path)
        for split_name, samples in splits.items():
            labels, probabilities = predict(model, samples)
            predictions = (probabilities >= 0.5).astype(int)
            prediction_path = (
                PREDICTION_DIR / f"{model_name}_seed{seed}_{split_name}.csv"
            )
            pd.DataFrame(
                {
                    "sample_id": [sample["sample_id"] for sample in samples],
                    "matched_pair_id": [
                        sample["matched_pair_id"] for sample in samples
                    ],
                    "label": labels.astype(int),
                    "probability": probabilities,
                    "prediction": predictions,
                    "correct": predictions == labels,
                    "m": [sample["m"] for sample in samples],
                    "k": [sample["k"] for sample in samples],
                }
            ).to_csv(prediction_path, index=False)
            replacement_rows.append(
                {
                    "model": model_name,
                    "role": spec["model_roles"][model_name],
                    "seed": seed,
                    "split": split_name,
                    **_metrics(labels, probabilities),
                    "selection_epoch": metadata["selection_epoch"],
                    "selected_temperature": metadata["selected_temperature"],
                    "checkpoint_sha256": metadata["checkpoint_sha256"],
                    "prediction_sha256": file_sha256(prediction_path),
                }
            )
    per_seed = pd.concat(
        [retained, pd.DataFrame(replacement_rows)], ignore_index=True
    ).sort_values(["model", "seed", "split"])
    per_seed.to_csv(RESULT_DIR / "per_seed_metrics.csv", index=False)
    numeric_metrics = [
        column
        for column in replacement_rows[0]
        if column
        not in {
            "model",
            "role",
            "seed",
            "split",
            "selection_epoch",
            "selected_temperature",
            "checkpoint_sha256",
            "prediction_sha256",
        }
    ]
    aggregate = (
        per_seed.groupby(["model", "role", "split"], sort=False)[numeric_metrics]
        .agg(["mean", "std"])
        .reset_index()
    )
    aggregate.columns = [
        "_".join(column).rstrip("_") if isinstance(column, tuple) else column
        for column in aggregate.columns
    ]
    counts = (
        per_seed.groupby(["model", "role", "split"], sort=False)["seed"]
        .nunique()
        .rename("seed_count")
        .reset_index()
    )
    aggregate = aggregate.merge(counts, on=["model", "role", "split"])
    aggregate.to_csv(RESULT_DIR / "aggregate_metrics.csv", index=False)
    return per_seed, aggregate


def verify_checkpoint_roundtrip() -> dict[str, Any]:
    failures: list[str] = []
    checked = 0
    sample = load_splits(["iid_test"])["iid_test"][:8]
    bx, by, _ = _tensor_batch(sample)
    for checkpoint_path in sorted(CHECKPOINT_DIR.glob("*.pt")):
        payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        first = initialize_model(payload["model_config"]).to(dtype=DTYPE).eval()
        second = initialize_model(payload["model_config"]).to(dtype=DTYPE).eval()
        first.load_state_dict(payload["state_dict"])
        second.load_state_dict(payload["state_dict"])
        with torch.no_grad():
            error = float((first(bx, by) - second(bx, by)).abs().max().item())
        checked += 1
        if error != 0.0:
            failures.append(f"{checkpoint_path.name}: {error}")
    report = {
        "status": "PASS" if checked == 35 and not failures else "FAIL",
        "checked_checkpoint_count": checked,
        "expected_checkpoint_count": 35,
        "failures": failures,
    }
    (RESULT_DIR / "checkpoint_roundtrip.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    return report


if __name__ == "__main__":
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    print(json.dumps(run_gate_a(), indent=2))
    print(json.dumps(run_gate_b(), indent=2))
    _, aggregate_frame, gate_c_report = run_experiments()
    print(aggregate_frame.to_string(index=False))
    print(json.dumps(gate_c_report, indent=2))
    print(json.dumps(verify_checkpoint_roundtrip(), indent=2))
