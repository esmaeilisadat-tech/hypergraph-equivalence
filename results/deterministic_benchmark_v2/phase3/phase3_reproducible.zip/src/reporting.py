"""Generate and verify the source-backed Phase 3 validation report."""

from __future__ import annotations

import json
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import pandas as pd
import torch

from src.phase3_data import PROJECT_ROOT, load_spec

RESULT_DIR = PROJECT_ROOT / "results" / "phase3"
REPORT_PATH = RESULT_DIR / "final_validation_report.md"
HEADLINE_START = "<!-- HEADLINE_METRICS_JSON_START -->"
HEADLINE_END = "<!-- HEADLINE_METRICS_JSON_END -->"
TEST_SPLITS = ["iid_test", "ood_template_test", "ood_size_test"]
DISPLAY_SPLITS = {
    "iid_test": "IID",
    "ood_template_test": "OOD-template",
    "ood_size_test": "OOD-size",
}


def _read_json(name: str) -> dict[str, Any]:
    return json.loads((RESULT_DIR / name).read_text(encoding="utf-8"))


def _headline_records(aggregate: pd.DataFrame) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for _, row in aggregate[
        aggregate["split"].isin(TEST_SPLITS)
    ].iterrows():
        for metric in (
            "accuracy",
            "balanced_accuracy",
            "macro_f1",
            "roc_auc",
            "pr_auc",
            "brier_score",
        ):
            records.append(
                {
                    "model": row["model"],
                    "role": row["role"],
                    "split": row["split"],
                    "metric": metric,
                    "mean": float(row[f"{metric}_mean"]),
                    "std": float(row[f"{metric}_std"]),
                    "seed_count": int(row["seed_count"]),
                }
            )
    return records


def _metric_table(aggregate: pd.DataFrame) -> str:
    lines = [
        "| Model | Role | Split | Accuracy | Balanced accuracy | Macro F1 | ROC-AUC | Seeds |",
        "|---|---|---|---:|---:|---:|---:|---:|",
    ]
    for _, row in aggregate[
        aggregate["split"].isin(TEST_SPLITS)
    ].iterrows():
        values = row.to_dict()
        values["split"] = DISPLAY_SPLITS[row["split"]]
        lines.append(
            "| {model} | {role} | {split} | {accuracy_mean:.6f} ± {accuracy_std:.6f} "
            "| {balanced_accuracy_mean:.6f} ± {balanced_accuracy_std:.6f} "
            "| {macro_f1_mean:.6f} ± {macro_f1_std:.6f} "
            "| {roc_auc_mean:.6f} ± {roc_auc_std:.6f} | {seed_count} |".format(**values)
        )
    return "\n".join(lines)


def _git(command: list[str]) -> str:
    return subprocess.run(
        ["git", *command],
        cwd=PROJECT_ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()


def generate_report() -> Path:
    spec = load_spec()
    aggregate = pd.read_csv(RESULT_DIR / "aggregate_metrics.csv")
    gate_a = _read_json("gate_a_report.json")
    gate_b = _read_json("gate_b_report.json")
    gate_c = _read_json("gate_c_report.json")
    split_audit = _read_json("split_overlap_audit.json")
    numerical = _read_json("numerical_audit.json")
    roundtrip = _read_json("checkpoint_roundtrip.json")
    primary = spec["primary_model"]
    test_rows = aggregate[aggregate["split"].isin(TEST_SPLITS)]
    ranking = (
        test_rows.groupby("model")["macro_f1_mean"]
        .mean()
        .sort_values(ascending=False)
    )
    best_value = float(ranking.iloc[0])
    best_models = [
        str(model)
        for model, value in ranking.items()
        if abs(float(value) - best_value) <= 1e-12
    ]
    best_model = ", ".join(f"`{model}`" for model in best_models)
    if len(best_models) > 1:
        best_model += " (exact tie)"
    primary_rows = test_rows[test_rows["model"] == primary]
    branch = _git(["branch", "--show-current"])
    commit = _git(["rev-parse", "HEAD"])
    status = (
        "PASS"
        if all(
            item["status"] == "PASS"
            for item in (
                gate_a,
                gate_b,
                gate_c,
                split_audit,
                numerical,
                roundtrip,
            )
        )
        else "FAIL"
    )
    primary_summary = "; ".join(
        f"{DISPLAY_SPLITS[row['split']]} accuracy "
        f"{row['accuracy_mean']:.6f} ± {row['accuracy_std']:.6f}, "
        f"macro F1 {row['macro_f1_mean']:.6f} ± {row['macro_f1_std']:.6f}"
        for _, row in primary_rows.iterrows()
    )
    gate_b_lines = "\n".join(
        f"- Seed {row['seed']}: {row['status']}; accuracy "
        f"{row['accuracy']:.6f}; macro F1 {row['macro_f1']:.6f}; "
        f"loss {row['loss']:.6f}; failed IDs: "
        f"{row['failed_sample_ids'] or 'none'}."
        for row in gate_b["per_seed"]
    )
    gate_c_lines = "\n".join(
        f"- Seed {row['seed']}: {row['status']}; training accuracy "
        f"{row['train_metrics']['accuracy']:.6f}; macro F1 "
        f"{row['train_metrics']['macro_f1']:.6f}; selected epoch "
        f"{row['selection_epoch']}; temperature "
        f"{row['selected_temperature']:.8f}."
        for row in gate_c["per_seed"]
    )
    numerical_lines = "\n".join(
        f"- `{name}`: maximum `{values['maximum']:.3e}`, "
        f"p99 `{values['p99']:.3e}`, failures `{values['failed_count']}`/"
        f"`{values['audited_count']}`, tolerance `{values['tolerance']:.1e}`."
        for name, values in numerical["quantities"].items()
    )
    headline_records = _headline_records(aggregate)
    report = f"""# Phase 3 Hypergraph Equivalence — Final Validation Report

## Technical summary

**Overall status: {status}.** The designated primary model is
`{primary}`; the numerically best-performing models under the locked ranking
(mean macro F1 across IID, OOD-template, and OOD-size) are {best_model}.
The primary result is: {primary_summary}.

The legacy Antigravity evidence was not reused as final evidence. Its leaked
train/validation/IID structures, weakened Gate B wording, inconsistent model
attribution, and incomplete numerical schema were replaced by a deterministic
zero-overlap corpus and a clean five-seed execution.

## The locked model comparison separates matching from non-matching baselines

{_metric_table(aggregate)}

Every row uses the same locked splits and seeds 42, 100, 2026, 777, and 999.
Means and sample standard deviations are computed directly from verified
per-seed prediction CSVs. Accuracy is the fraction correctly classified at
threshold 0.5; balanced accuracy averages class recalls; macro F1 averages the
two class F1 values; ROC-AUC and PR-AUC use probabilities; Brier score is mean
squared probability error.

{HEADLINE_START}
{json.dumps(headline_records, sort_keys=True)}
{HEADLINE_END}

## Scope and data definitions eliminate the inherited leakage

The task distinguishes class 2 pairs (EE-equivalent incidence stars that are
not strongly structurally equivalent) from class 3 pairs (equal multisets of
incident neighbor sets). Each negative/positive matched pair shares a generated
base, dimensions, margins, and nuisance statistics. Train, validation, IID,
OOD-template, and OOD-size contain 800, 800, 800, 800, and 400 samples,
respectively. OOD-template uses three degree-preserving switches; OOD-size uses
15–30 incident rows and 12–20 neighbor columns.

Split audit status is `{split_audit['status']}` with
`{split_audit['problem_count']}` problems and zero prohibited sample-ID,
matched-pair, base-hash, or invariant-structure overlaps in every split pair.
Generation and loading are deterministic, labels agree with the exact multiset
oracle, and padding/masks were independently checked.

## Model and experimental design

`MatchingNetwork` is the designated primary model—not whichever model happens
to rank first. It uses fixed normalized L1 row cost, a balanced log-domain
Sinkhorn coupling, and a learned symmetric classifier. The baselines are
`MLP_Baseline`, `NestedDeepSets`, and `BipartiteEncoder`; the ablations are
`LearnedCostSinkhorn`, `StraightThroughHungarian`, and `NoSinkhorn`.

For every model and seed, only validation macro F1 followed by validation loss
selects the checkpoint. IID and both OOD splits are evaluation-only. The
artifacts preserve selection epoch, selected temperature, Sinkhorn iteration
counts, device, dtype, checkpoint hash, and per-sample probabilities.

## Gate A verifies the oracle and normalized coupling

Gate A is `{gate_a['status']}` on `{gate_a['oracle_sample_count']}` samples with
oracle accuracy `{gate_a['oracle_accuracy']:.6f}`. A normalized coupling has
total mass 1; for `m` equally weighted valid rows, each hard matched entry is
approximately `1/m`, not 1. The 500-iteration float64 evidence has maximum total
mass error `{gate_a['maximum_total_mass_error']:.3e}`, row residual
`{gate_a['maximum_row_marginal_residual']:.3e}`, and column residual
`{gate_a['maximum_column_marginal_residual']:.3e}` against tolerance
`{gate_a['tolerance']:.1e}`.

## Gate B passes the unchanged 0.99 rule for every seed

{gate_b_lines}

The rule remains accuracy ≥ 0.99, macro F1 ≥ 0.99, and each class F1 ≥ 0.98.
No sample or threshold was removed after observing results.

## Gate C uses validation-only selection and passes every seed

{gate_c_lines}

The locked training thresholds are accuracy, balanced accuracy, and macro F1
at least 0.95, with each class recall at least 0.90.

## The complete float64 audit has no unexplained failures

The audit status is `{numerical['status']}` over
`{numerical['audited_sample_count']}` seed–sample evaluations, using compact
unpadded submatrices, explicit uniform marginals, deterministic permutations,
float64, and `{numerical['sinkhorn_iterations']}` iterations.

{numerical_lines}

Rows denote unordered incident hyperedges, so row-order invariance is mandatory.
Columns denote neighbor nodes, so joint column relabeling is mandatory. Root
swap requires cost/coupling transpose equivariance and final-score invariance.

## Limitations, robustness, and interpretation

- The corpus is synthetic and targets the local incidence-star criterion from
  the cited formulation; it does not establish performance on arbitrary
  empirical hypergraphs or every hierarchy level in Eidi et al.
- WL digests are screening identifiers, not proofs of graph isomorphism.
  Candidates with ambiguous positive/negative digests were rejected, and exact
  labels use multiset equality plus Hungarian cost rather than WL hashes.
- Five seeds quantify optimization variability on fixed data, not uncertainty
  over an external data-generating population.
- Strong OOD performance, if present, supports this locked generator family;
  it is not a causal claim or a universal theorem about learned matchers.

## Reproduction and evidence

Branch: `{branch}`. Baseline commit: `{commit}`. Python `{platform.python_version()}`
via the documented project environment; PyTorch `{torch.__version__}` on CPU.
The preserved pre-takeover archive is
`results/phase3_archive/20260727_102315`.

Run the logged clean pipeline from the repository root using the interpreter
recorded in `results/phase3/run_manifest.json`. Evidence is in
`per_seed_metrics.csv`, `aggregate_metrics.csv`, the gate/audit JSON files,
`checkpoints/`, `predictions/`, both clean-executed notebooks, and the final
artifact manifest.

## Recommended next steps

Use the locked artifacts as the reproducible Phase 3 reference. Any follow-up
should add genuinely new generator families or empirical incidence stars while
preserving validation-only selection and rerunning the same structural audit.

## Further questions

The most useful next scientific question is whether the ranking and OOD-size
behavior persist under independently designed generators that preserve the
same formal class definitions but alter degree, sparsity, and automorphism
distributions.
"""
    REPORT_PATH.write_text(report, encoding="utf-8")
    return REPORT_PATH


def verify_report_consistency() -> dict[str, Any]:
    report = REPORT_PATH.read_text(encoding="utf-8")
    if HEADLINE_START not in report or HEADLINE_END not in report:
        result = {"status": "FAIL", "reason": "headline marker missing"}
    else:
        payload = report.split(HEADLINE_START, 1)[1].split(HEADLINE_END, 1)[0]
        report_records = json.loads(payload.strip())
        aggregate = pd.read_csv(RESULT_DIR / "aggregate_metrics.csv")
        expected = _headline_records(aggregate)
        failures: list[dict[str, Any]] = []
        report_by_key = {
            (r["model"], r["split"], r["metric"]): r for r in report_records
        }
        expected_by_key = {
            (r["model"], r["split"], r["metric"]): r for r in expected
        }
        if set(report_by_key) != set(expected_by_key):
            failures.append(
                {
                    "field": "model/split/metric keys",
                    "expected": sorted(expected_by_key),
                    "observed": sorted(report_by_key),
                }
            )
        for key in sorted(set(report_by_key) & set(expected_by_key)):
            for field in ("role", "mean", "std", "seed_count"):
                observed = report_by_key[key][field]
                wanted = expected_by_key[key][field]
                if (
                    abs(float(observed) - float(wanted)) > 1e-12
                    if field in {"mean", "std"}
                    else observed != wanted
                ):
                    failures.append(
                        {
                            "key": key,
                            "field": field,
                            "expected": wanted,
                            "observed": observed,
                        }
                    )
        result = {
            "status": "PASS" if not failures else "FAIL",
            "checked_headline_count": len(expected),
            "failures": failures,
        }
    (RESULT_DIR / "report_consistency.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    return result


if __name__ == "__main__":
    print(generate_report())
    print(json.dumps(verify_report_consistency(), indent=2))
