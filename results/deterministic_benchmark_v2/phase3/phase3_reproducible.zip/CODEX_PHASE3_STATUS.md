# Codex Phase 3 Status

Last updated: 2026-07-27 17:28:00 UTC

## Repository state

- Workspace: `hypergraph_equivalence`
- Branch: `codex-phase3-final`
- Baseline commit: `119343d0ad758f8c4a78d3831e8727d37255a3be`; the supplied workspace contained no `.git` directory or recoverable Git history, so Git was initialized in place.
- Legacy archive: `results/phase3_archive/20260727_102315`
- Archive inventory: 20 files, 1,789,035 bytes.

## Authoritative project specification discovered

- `AGENTS.md` is the permanent Phase 3 completion contract.
- `CODEX_PHASE3_HANDOFF.md` is the active takeover and execution contract.
- Existing Antigravity code, outputs, metrics, checkpoints, reports, notebooks, and PASS claims are unverified legacy evidence.
- Designated primary model: `MatchingNetwork`, the fixed-L1 Sinkhorn matching model. This is stated by `src/config_manager.py` and independently by the inherited gate script.
- Legacy numerically best model: `LearnedCostSinkhorn` in the archived CSVs, but the result is unverified and was misreported in the legacy narrative.
- Required baselines: `MLP_Baseline`, `NestedDeepSets`, `BipartiteEncoder`.
- Required ablations: `LearnedCostSinkhorn`, `StraightThroughHungarian`, `NoSinkhorn`.
- Gate A: exact multiset/Hungarian oracle verification plus mathematically correct normalized Sinkhorn evidence.
- Gate B: balanced tiny-batch capability test with the non-weakened `0.99` accuracy and macro-F1 rule across all five seeds; inherited source also specifies per-class F1 at least `0.98`.
- Gate C: final primary-model training requirements plus validation-only checkpoint selection and complete per-seed evaluation artifacts.
- Default locked seeds, unless superseded by an authoritative repository specification: `42`, `100`, `2026`, `777`, `999`.
- Required splits: train, validation, IID test, OOD-template test, and OOD-size test.

## Files inspected

- `AGENTS.md` (read completely)
- `CODEX_PHASE3_HANDOFF.md` (read completely)
- Complete non-`.git` path inventory via `rg --files -uu -g '!.git/**'`
- Workspace and parent directory listings
- Git metadata search in the workspace and all parents
- Initial `results/phase3` archive inventory
- All 27 files under `src/`
- All five repository test files
- All seven locked split JSON files and their shapes, label counts, and hashes
- All root notebooks, including cell sources, execution state, and cached errors
- Eidi et al. PDF: extracted text plus visual inspection of all 28 rendered pages
- Legacy archive `20260727_080146` report, metrics, audits, predictions/checkpoints manifest, and artifact manifest

## Changes made

- Initialized Git because the supplied workspace had no `.git` metadata.
- Created branch `codex-phase3-final`.
- Archived current `results/phase3` contents and root Phase 3 notebooks/logs under `results/phase3_archive/20260727_102315`.
- Created this persistent status file.
- Rendered and visually inspected the source paper under temporary `tmp/pdfs/eidi/`.
- Established the only usable Python environment at `C:/Users/esmae/Documents/Educx Kurs machine lerning/aufgabe/.venv/Scripts/python.exe` (Python 3.11.15, PyTorch 2.12.1 CPU).
- Added `.gitignore` for caches, temporary renders, ZIPs, and preserved archives.
- Committed the untouched takeover baseline on `codex-phase3-final`.
- Added the authoritative locked experiment specification (`phase3_spec.json`) and model configurations.
- Replaced nondeterministic/leaking split generation with deterministic, stable-ID generation that rejects invariant structure and base-graph overlap.
- Replaced the primary/ablation matching implementation with normalized-mass, explicitly symmetric Sinkhorn/Hungarian implementations and added required invariant baselines.
- Added epsilon-scaled log-domain Sinkhorn updates plus a transpose-equivariant Dykstra transport-polytope finish for the 500-iteration float64 verification path.
- Replaced the split audit with deterministic regeneration, oracle, tensor, hash, overlap, duplicate, and padding checks.
- Added a pinned project dependency declaration.
- Installed the declared `pytest==8.4.1` into the verified project environment and reconciled all dependency pins to installed versions.
- Regenerated and froze all five locked splits after rejecting ambiguous WL-digest collisions.
- Implemented the unified Gate A/B/C, seven-model/five-seed training, prediction, checkpoint, metric aggregation, and round-trip verification pipeline.
- Implemented the complete five-seed/all-test-sample compact float64 numerical audit, including root swap, assignment transpose, node-row, and joint-column permutations.
- Recorded the new final-handoff rule: preserve the eight-stage sequence, reconcile this file after each remaining major stage, and paste its complete contents inline at completion.
- Moved obsolete Antigravity runners, duplicate generators, cached notebooks, and chat-specific files into `docs/legacy/antigravity/`; they remain preserved and tracked but are no longer imported as active source.
- Added portable logging, frozen-evidence validation, report consistency, manifest hash verification, and extracted-ZIP smoke testing.

## Commands executed and return codes

- `git status --short --branch; git diff --stat; git diff --cached --stat` — return code 1; confirmed no Git repository existed.
- `Get-Content AGENTS.md -Raw; Get-Content CODEX_PHASE3_HANDOFF.md -Raw` — return code 0.
- `rg --files -uu -g '!.git/**'` — return code 0.
- Parent/workspace directory and `.git` searches — return code 0, except one PowerShell formatting pipeline parse error (return code 1); the corrected directory searches confirmed no `.git`.
- `git init -b codex-phase3-final; git branch --show-current; git status ...` — return code 0.
- Timestamped archive creation and inventory — return code 0.
- Legacy source, test, notebook, report, manifest, metric, and audit inspection commands — return code 0.
- Source-paper PDF rendering/extraction — return code 0 after bypassing a broken wrapper and invoking Poppler directly.
- Baseline test scripts — three pass, two fail with missing `generate_binary_dataset`/`build_hypergraph_from_bipartite` imports.
- Split profiling — return code 0.
- Invariant leakage check — return code 0; train/validation/IID share 793 WL-invariant structures, and each contains seven within-split WL duplicates.
- Oracle/shape validation — return code 0; all labels and matrix shapes match the exact oracles.
- `python -m compileall -q src` — return code 0.
- Seven-model forward smoke test — one compatibility failure from unavailable `torch.flatnonzero`; repaired with `torch.nonzero(...).flatten()`, then return code 0.
- Float64 500-iteration Sinkhorn smoke audit on 100 generated samples — return code 0; maximum marginal residual `6.41e-14`, mass error `2.22e-16`, non-negativity violation `0`.
- Final deterministic split regeneration — return code 0; file SHA-256 values: train `68e7feabb56592cb5f3ccdf588f8d3eeba38b7815d94f9ab8287cad2071b7a7e`, validation `1a1d22b356ea82a1d9f7b983e2f9fc54813e9753a5da2dc63ad8db6b60418bdb`, IID `a91f93999714ebf409611fc09bcc5c582744b7afac7295e5bbba20dcd3dfb8d9`, OOD-template `c1fad4d214ce469c3fc66d47ec0b6d39ed44c25d9e24e90e87733dc043e537e6`, OOD-size `059f9b79259442640554907bae316af6b07a349cfa3cdd67638bd8f886616ace`.
- Complete split audit — return code 0; `PASS`, 0 problems, sizes 800/800/800/800/400, balanced classes, unique invariant structures 800/800/800/800/400, and zero sample/pair/base/invariant overlap for all prohibited split pairs.
- Gate A — return code 0; `PASS` on 3,600 samples, oracle accuracy `1.0`, maximum row residual `6.147859998861804e-15`, maximum column residual `5.2735593669694936e-15`, 500 iterations, tolerance `1e-8`.
- Gate B — return code 0; `PASS` for seeds 42, 100, 2026, 777, and 999. Every seed achieved accuracy `1.0` and macro F1 `1.0` on 64 balanced samples under the unchanged `0.99` thresholds.
- Full experiment command was launched at 12:53 local time. The shell tool returned code `124` after its two-hour observation window, but process inspection confirmed that the original experiment process remains active (`PID 4280`, compute child `PID 28804`). It has not been cancelled, restarted, or repeated.
- Live stage-5 inventory at 14:55 local time: 28/35 checkpoints and 140/175 prediction files complete. Completed runs cover all five seeds for MLP_Baseline, NestedDeepSets, BipartiteEncoder, MatchingNetwork, and LearnedCostSinkhorn, plus seeds 42, 100, and 2026 for StraightThroughHungarian.
- The original full-experiment process exited naturally at 15:05 local time and completed all 35 model/seed runs, 175 prediction files, 175 per-seed metric rows, and 35 aggregate model/split rows. No completed training was restarted.
- Gate C — `PASS` for all five seeds. MatchingNetwork training accuracy and macro F1 are `1.0` for seeds 42, 100, 2026, 777, and 999; every checkpoint selection epoch is 160 under validation macro F1 followed by validation loss.
- Checkpoint save/load round trip — return code 0; `PASS` for all 35 checkpoints with zero failures.
- Primary MatchingNetwork test metrics: IID accuracy/macro F1/ROC-AUC `1.0/1.0/1.0`; OOD-template `1.0/1.0/1.0`; OOD-size `1.0/1.0/1.0`; all standard deviations `0.0`, five seeds each.
- LearnedCostSinkhorn and StraightThroughHungarian also achieve accuracy/macro F1/ROC-AUC `1.0/1.0/1.0` on all three test splits. This tie does not change primary-model identity.
- NoSinkhorn accuracy is IID `0.6025 ± 0.140690`, OOD-template `0.6355 ± 0.185751`, and OOD-size `0.5175 ± 0.027386`. The three required baselines remain at accuracy `0.5`, as expected for margin-only summaries on matched nuisance statistics.
- First complete float64 audit run — return code 0 but scientific status `FAIL`, correctly preserved in the original command output. It audited all 10,000 seed–sample cases and found 1,653 samples with at least one failure. The gauge-fixed Newton finish left maximum row/column residuals `1.7478114698719904e-4`/`1.2801104745845115e-4`, coupling-transpose error `2.0661321823547418e-4`, and row-permutation logit error `1.0045240724384286e-2`.
- Root cause: the Newton balancing finish was ill-conditioned near hard assignments and its fixed gauge was not transpose-equivariant. Acceptance thresholds and tested quantities were not changed.
- Repair: replaced the Newton finish with Dykstra projection onto the nonnegative uniform-marginal transport polytope and averaged direct/transposed projection paths. Targeted reruns of all four worst samples now have coupling-transpose errors at most `5.55e-17`, row residual at most `8.18e-14`, column residual at most `8.67e-14`, and matching-cost swap error at most `3.12e-17`.
- Repaired full numerical audit — return code 0; `PASS` with 0 failed samples across 10,000 seed–sample cases at float64 and 500 iterations.
- Numerical maxima: cost/coupling finite violations `0`; non-negativity violation `0`; cost-transpose `0`; coupling/assignment-transpose `7.252086444224297e-15`; matching-cost swap `2.914335439641036e-16`; equality-score swap `1.1102230246251565e-15`; final logit/probability swap `0`; total mass `4.440892098500626e-16`; row marginal `1.0171030684347215e-13`; column marginal `1.0551282070281331e-13`; row-permutation coupling `9.096889908022376e-15`, logit `5.901945598907332e-12`, probability `1.0302869668521453e-13`; joint-column cost/coupling/logit/probability `0`.
- Initial replacement test collection failed because pytest discovered the legacy `scratch/test_sinkhorn.py`; resolved by locking `testpaths = tests` in `pytest.ini` while preserving the scratch file as legacy evidence.
- The first locked test run then exposed `StraightThroughHungarian` row-order dependence under optimal-assignment ties. Its equality feature was repaired to depend on invariant optimal total cost rather than an arbitrary tie-broken assignment. All five contract tests now pass.
- Before replacing affected evidence, archived the five old StraightThroughHungarian checkpoints, 25 predictions, and metric CSVs under `results/phase3_archive/20260727_161900_straight_through_tie_fix`.
- Reran only the five affected StraightThroughHungarian seeds; the other 30 model/seed runs were not repeated. The repaired ablation retains accuracy and macro F1 `1.0 ± 0.0` on IID, OOD-template, and OOD-size.
- Final checkpoint round trip — return code 0; `PASS` for all 35 repaired checkpoints.
- Final report generation and automated consistency check — return code 0; `PASS` across 126 model/split/metric headline records with exact model, role, mean, standard deviation, and five-seed count agreement.
- Clean notebook execution — return code 0 for both notebooks. `Phase3_Research.ipynb` and `Phase3_Explained_FA.ipynb` each have 7/7 code cells executed and zero error outputs.
- The technical report follows the technical-report workflow: answer-first summary, model comparison, definitions, methods, gates, robustness, limitations, and evidence-backed next questions.
- Final active-source import log — return code 0; all 13 active modules import.
- Final active-source tests — return code 0; 5/5 tests pass.
- Frozen-evidence metric validation — first return code 1 because CSV round-trip differences exceeded an unnecessarily strict `1e-10` metric tolerance; preserved that failed log. Corrected metric-file tolerance `1e-7` is below float32 decimal serialization precision and does not alter the `1e-8` structural threshold. Retry return code 0 with maximum recomputation error `3.143554050399899e-8`.
- Logged gate, numerical-audit, report-consistency, notebook-execution, split-integrity, manifest, and ZIP validations — all final return codes 0.
- First full manifest/ZIP packaging pass — `PASS`: 330 hashed evidence entries; 331 ZIP entries; all paths present; all hashes recomputed; clean extraction succeeded; extracted imports/data/model smoke test succeeded.
- Final artifact paths: report `results/phase3/final_validation_report.md`; notebooks `notebooks/Phase3_Research.ipynb` and `notebooks/Phase3_Explained_FA.ipynb`; checkpoints `results/phase3/checkpoints/`; predictions `results/phase3/predictions/`; manifests `results/phase3/run_manifest.json` and `results/phase3/final_artifact_manifest.json`; ZIP `results/phase3/phase3_reproducible.zip`.

## Completed requirements

- Read both control files completely.
- Inspected initial Git state and diff availability.
- Inspected the complete non-`.git` repository path inventory.
- Created the required dedicated branch.
- Created a timestamped archive before overwriting any Phase 3 result.
- Preserved all currently present Phase 3 output files plus root legacy notebooks and logs.
- Completed the takeover classification of the active source, tests, notebooks, data, and main legacy evidence.
- Identified the designated primary model, required baselines/ablations, locked seeds/splits, and inherited gate definitions.
- Implemented and smoke-tested the deterministic data/model/numerical foundations needed by the clean run.
- Completed stage 4 of 8: repaired deterministic data, model, gate, audit, and reproducibility foundations.
- Gate A is verified PASS.
- Gate B is verified PASS for all five locked seeds.
- Completed stage 5 of 8: all models, seeds, splits, checkpoints, predictions, metrics, and Gate C evidence.
- Completed stage 6 of 8: strict numerical audit, report consistency, repository tests, and clean-executed English/Persian notebooks.
- Completed stage 7 of 8: command logs, SHA-256 manifests, complete ZIP, extraction, hash verification, and extracted smoke tests.
- Completed stage 8 of 8: final frozen-evidence validation and exact artifact handoff.
- Overall current Phase 3 status: `PASS`; no mandatory item is FAIL, PARTIAL, NOT RUN, BLOCKED, or missing evidence.

## Historical failed evidence and resolved failures

- Legacy split integrity: FAIL because train, validation, and IID test reuse 793 permutation-equivalent underlying structures.
- Legacy report consistency: FAIL because the report weakens Gate B to `0.98+`, claims four validation seeds, omits exact OOD-size metrics, and conflicts with archived CSV values.
- Legacy numerical audit: FAIL as completion evidence because it omits required quantities, uses an incomplete schema, and inherited code contains contradictory mass assumptions.
- Baseline repository tests: FAIL (2/5 scripts fail import).
- First strict numerical audit: FAIL; preserved and resolved by the Dykstra transport projection, followed by a full 10,000-case PASS.
- First final metric-file reconciliation: FAIL only at `3.14e-8` float32 CSV round-trip error against `1e-10`; preserved and resolved with a documented `1e-7` metric serialization tolerance.
- Current mandatory failures: none.

## Pending requirements

- None.

## Current blockers

- None.

## Current running process

- None.

## Remaining stages

- Stage 5: full experiments, Gate C, checkpoints, predictions, and metrics — completed.
- Stage 6: complete numerical audit, final report, and clean-executed notebooks — completed.
- Stage 7: manifests, hashes, logged verification commands, and full reproducible ZIP — completed.
- Stage 8: final clean validation and exact handoff — completed.

## Final model results

- Designated primary: `MatchingNetwork`.
- Numerically best: exact three-way tie between `MatchingNetwork`, `LearnedCostSinkhorn`, and `StraightThroughHungarian` at mean macro F1 `1.0` across IID, OOD-template, and OOD-size.
- MatchingNetwork IID: loss is recorded per seed; accuracy `1.0 ± 0.0`, balanced accuracy `1.0 ± 0.0`, macro F1 `1.0 ± 0.0`, ROC-AUC `1.0 ± 0.0`, five seeds.
- MatchingNetwork OOD-template: accuracy `1.0 ± 0.0`, balanced accuracy `1.0 ± 0.0`, macro F1 `1.0 ± 0.0`, ROC-AUC `1.0 ± 0.0`, five seeds.
- MatchingNetwork OOD-size: accuracy `1.0 ± 0.0`, balanced accuracy `1.0 ± 0.0`, macro F1 `1.0 ± 0.0`, ROC-AUC `1.0 ± 0.0`, five seeds.
- Gate A: `PASS`, 3,600/3,600 correct, maximum row residual `6.147859998861804e-15`, maximum column residual `5.2735593669694936e-15`.
- Gate B seed 42: `PASS`, loss `0.004119258599548861`, accuracy/macro F1 `1.0/1.0`.
- Gate B seed 100: `PASS`, loss `0.004119258599548861`, accuracy/macro F1 `1.0/1.0`.
- Gate B seed 2026: `PASS`, loss `0.004119258599548861`, accuracy/macro F1 `1.0/1.0`.
- Gate B seed 777: `PASS`, loss `0.004119258599548861`, accuracy/macro F1 `1.0/1.0`.
- Gate B seed 999: `PASS`, loss `0.004119258599548861`, accuracy/macro F1 `1.0/1.0`.
- Gate C seeds 42, 100, 2026, 777, and 999: each `PASS` with training accuracy, balanced accuracy, macro F1, and both class recalls `1.0`; selected epoch 160; selected temperature `0.004999999888241291`.

## Git diff summary

- Branch `codex-phase3-final`, baseline commit `119343d0ad758f8c4a78d3831e8727d37255a3be`.
- Tracked diff summary before final generated/untracked artifacts: 57 files, 903,024 insertions, 11,313 deletions.
- Apparent deletions of legacy files are tracked moves into `docs/legacy/antigravity/`; no legacy evidence was discarded.

## Remaining scientifically honest limitations

- The corpus is synthetic and tests the locked local incidence-star formulation, not arbitrary empirical hypergraphs.
- Five seeds measure optimization variability on fixed data, not uncertainty over an external population.
- WL hashes are screening identifiers rather than graph-isomorphism proofs; exact labels use row-multiset equality and Hungarian cost.
- The three perfect matching variants are tied on these locked generators, so this experiment does not rank them beyond that tie.
- The system `python` launcher is unavailable on this machine; the verified environment is Python 3.11.15/PyTorch 2.12.1 CPU and all portable commands use the interpreter placeholder documented in the run manifest.

## Exact next command

None. The Phase 3 completion contract is satisfied.
